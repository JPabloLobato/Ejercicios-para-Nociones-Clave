//
// Created by juanp on 18/10/2023.
//

#ifndef EJERCICIO345_FUNCIONES_H
#define EJERCICIO345_FUNCIONES_H
int suma(int a, int b);
int resta(int a, int b);

#endif