//
// Created by juanp on 18/10/2023.
//

#ifndef EJERCICIO345_MATEMATICAS_H
#define EJERCICIO345_MATEMATICAS_H


class matematicas {

    int suma(int a, int b);
    int resta(int a, int b);
    int multiplicacion(int a, int b);
    int division(int a, int b);

};


#endif //EJERCICIO345_MATEMATICAS_H
