//
// Created by juanp on 18/10/2023.
//

#include "nuevo.h"
#include <fmt/core.h>

int main() {
    fmt::print("¡Hola desde nuevo.cpp!\n");
    return 0;
}