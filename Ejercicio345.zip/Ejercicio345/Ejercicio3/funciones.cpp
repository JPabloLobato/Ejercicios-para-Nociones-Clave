//
// Created by juanp on 18/10/2023.
//

#include "funciones.h"
int suma(int a, int b) {
    return a + b;
}

int resta(int a, int b) {
    return a - b;
}
