//
// Created by juanp on 18/10/2023.
//

#include "matematicas.h"
int suma(int a, int b) {
    return a + b;
}

int resta(int a, int b) {
    return a - b;
}

int multiplicacion(int a, int b) {
    return a * b;
}

int division(int a, int b) {
    if (b == 0) {
        // Manejo de división por cero
        return 0;
    }
    return a / b;
}